SpoolTag Studio portable Linux bundle

Run ./SpoolTagStudio from this directory. No Python installation is required.
The application runs a private local server and opens in your default web
browser. No Internet connection is needed while using it.

NFC readers require the PC/SC service (pcscd) and access to the reader device.
For Chameleon Ultra serial access, your user may need membership in the
dialout group. Log out and back in after adding group membership.
